/* ========================================
 *
 * Brandon Erickson (bjericks@ucsc.edu)
 *
 * CSE 121 LAB 1 PART 3: PROXIMITY DETECTOR
 *
 * Configures a 100 cm proximity detector
 * using a HC-SR04 ultrasonic sensor. When
 * an object is detected within the target
 * range, an LED is lit for at least 5 secs.
 *
 * ========================================
*/
#include "project.h"

/* Set parameters */
#define MEASURE_DELAY__   500      // delay between trigger pulses
#define US_TO_CM_CONV__   58       // 58 = 2000000/34000, used in distance calculation
#define MAX_DISTANCE_CM__ 400      // maximum distance between object and ultrasonic sensor to light LED
#define MAX_COMPARE__     1100     // maximum compare value of PWM (+ buffer)
#define ECHO_TIMER_TC__   65535    // maximum value of Echo_Timer

/* ISR for falling edge of Echo pulse */

uint16_t distance = 0; // Last echo pulse width measurement

void ISR_edge(void) {
    /* 
    *  Upon falling edge of echo pulse, measure pulse width
    *  with Echo_Timer reading and reset timer
    *  Then clear interrupt
    */
    uint16_t echo_width;
    echo_width = Echo_Timer_GetPeriod() - Echo_Timer_GetCounter();
    distance = echo_width/US_TO_CM_CONV__;
    // compare = distance * max_compare/400
    PWM_1_SetCompare0(distance * MAX_COMPARE__/MAX_DISTANCE_CM__);
    
    /* 
    *  If the sensor detects an object within 100 cm, reset the
    *  LED Counter. Resetting the LED counter causes the LED to
    *  light up for at least 5 more seconds.
    */
//    if (distance <= MAX_DISTANCE_CM__ /* = 100 cm */) {
//        LED_Reset_Reg_Write(1);
//        Cy_SysLib_Delay(2); // hold for >1 clock cycle
//        LED_Reset_Reg_Write(0);
//        LED_Reg_Write(1);
//    }
    
    Echo_Timer_SetCounter(ECHO_TIMER_TC__);
    
    NVIC_ClearPendingIRQ(Echo_Int_cfg.intrSrc);
}


int main(void)
{
    __enable_irq(); /* Enable global interrupts. */
    
    /* Initialize HW components */
    
    // Echo interrupts
    Cy_SysInt_Init(&Echo_Int_cfg, ISR_edge);
    NVIC_EnableIRQ(Echo_Int_cfg.intrSrc);
    NVIC_ClearPendingIRQ(Echo_Int_cfg.intrSrc);
    
    // Trig Counter TCPWM component
    Trig_Counter_Init(&Trig_Counter_config);
    Trig_Counter_Enable();
    Trig_Counter_TriggerStart();
    
    // Echo Timer TCPWM component
    Echo_Timer_Init(&Echo_Timer_config);
    Echo_Timer_Enable();
    Echo_Timer_TriggerStart();
    
//    /* 
//    *  1 kHz LED Counter TCPWM component
//    *  When LED reaches TC (5000), LED is turned off (set to 1)
//    *  This counter is reset when an object is detected close enough to the sensor
//    */
//    LED_Counter_Init(&LED_Counter_config);
//    LED_Counter_Enable();
//    LED_Counter_SetCounter(LED_TC__); // turns off LED at start
//    LED_Counter_TriggerStart();
    
    // PWM
    PWM_1_Init(&PWM_1_config);
    PWM_1_Enable();
    PWM_1_TriggerStart();
    
    
    /* 
    *  Main loop: Generate a 10 us pulse every 500 ms
    */
    for(;;)
    {
        Reset_Reg_Write(1);
        Cy_SysLib_DelayUs(2);
        Reset_Reg_Write(0);
        Trigger_Reg_Write(1);
        
        Cy_SysLib_Delay(MEASURE_DELAY__ /*ms*/);
    }
}

/* [] END OF FILE */
