/* ========================================
 *
 * Brandon Erickson (bjericks@ucsc.edu)
 *
 * CSE 121 LAB 1 PART 3: PROXIMITY DETECTOR
 *
 * Configures a 100 cm proximity detector
 * using a HC-SR04 ultrasonic sensor. When
 * an object is detected within the target
 * range, an LED is lit for at least 5 secs.
 *
 * ========================================
*/
#include "project.h"

/* 
 *  Core 0 is unused for this lab exercise, and only serves to enable Core 1.
*/

int main(void)
{
    __enable_irq(); /* Enable global interrupts. */
    /* Enable CM4.  CY_CORTEX_M4_APPL_ADDR must be updated if CM4 memory layout is changed. */
    Cy_SysEnableCM4(CY_CORTEX_M4_APPL_ADDR);
    
    
    
    for (;;) 
    {
        
    }
}

/* [] END OF FILE */
